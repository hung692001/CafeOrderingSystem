# Cafe-Ordering-System

This is my COMP SCI 1102 Object Oriented Programming group project. (2021 Year 1 Semester 2)

This project was collaboratively completed by Jiajun Yu, Hung Yee Wong and Guan Chern Liew.

This cafe ordering system allows users to order items to their liking.

The project was written in C++ and tested by Makefile.
